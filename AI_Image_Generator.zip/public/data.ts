export const images = [
  {
    src: "/Women/1.webp",
    alt: "1.webp",
    id: 1,
  },
  {
    src: "/Women/2.jpg",
    alt: "2.jpg",
    id: 2,
  },
  {
    src: "/Women/3.jpg",
    alt: "3.jpg",
    id: 3,
  },
  {
    src: "/Women/4.jpg",
    alt: "4.jpg",
    id: 4,
  },
  {
    src: "/Women/5.jpg",
    alt: "5.jpg",
    id: 5,
  },
  {
    src: "/Women/6.jpg",
    alt: "6.jpg",
    id: 6,
  },

  {
    src: "/Women/7.jpg",
    alt: "7.jpg",
    id: 7,
  },
  {
    src: "/Women/8.jpg",
    alt: "8.jpg",
    id: 8,
  },
  {
    src: "/Women/9.webp",
    alt: "9.webp",
    id: 9,
  },
  {
    src: "/Women/10.jpg",
    alt: "10.jpg",
    id: 10,
  },
];
